import { type IMAppConfig } from 'jimu-core';
export declare class UseMapService {
    remove(appConfig: IMAppConfig, mapWidgetId: string): IMAppConfig;
}
declare const _default: UseMapService;
export default _default;
