import { type IMAppConfig } from 'jimu-core';
export declare class DataActionService {
    removeFromWidget(appConfig: IMAppConfig, widgetId: string): IMAppConfig;
}
declare const _default: DataActionService;
export default _default;
