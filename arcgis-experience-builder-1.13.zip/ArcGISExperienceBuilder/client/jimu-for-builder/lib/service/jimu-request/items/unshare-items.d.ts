import { type IParams } from '@esri/arcgis-rest-request';
export declare function unShareItems(requestOptions: IParams): Promise<any>;
