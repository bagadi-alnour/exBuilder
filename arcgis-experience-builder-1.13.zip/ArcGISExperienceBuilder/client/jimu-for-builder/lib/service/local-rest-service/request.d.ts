import { type IRequestOptions } from '@esri/arcgis-rest-request';
export declare function request(url: string, requestOptions?: IRequestOptions, requestType?: 'GET' | 'POST'): Promise<any>;
