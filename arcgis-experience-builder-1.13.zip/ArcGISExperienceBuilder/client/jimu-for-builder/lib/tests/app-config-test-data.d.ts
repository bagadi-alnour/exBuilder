export declare const builderState: any;
