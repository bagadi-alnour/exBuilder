var theme = require('jimu-for-test/lib/theme-mock');

module.exports = theme;
