import { JimuLayerView } from './jimu-layer-view';
export declare class JimuSubTypeGroupLayerView extends JimuLayerView {
    ready(): Promise<this>;
}
