import { JimuMapServiceLayerView } from './jimu-mapservice-layer-view';
export declare class JimuTileLayerView extends JimuMapServiceLayerView {
}
