import { type JimuMapView } from '../jimu-map-view';
import { type JimuLayerView } from './jimu-layer-view';
export declare function toggleHighlightLayerVisible(jimuMapView: JimuMapView, jimuLayerView: JimuLayerView): void;
