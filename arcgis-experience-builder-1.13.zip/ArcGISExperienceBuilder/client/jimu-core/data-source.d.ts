import { JimuCoreDataSourceFactory } from './lib/data-sources';
export default JimuCoreDataSourceFactory;
export * from './lib/data-sources';
