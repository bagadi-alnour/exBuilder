import { jsx } from '@emotion/react';
import { type DialogProps } from '../types';
export declare function AppDialog(props: DialogProps): jsx.JSX.Element;
export default AppDialog;
