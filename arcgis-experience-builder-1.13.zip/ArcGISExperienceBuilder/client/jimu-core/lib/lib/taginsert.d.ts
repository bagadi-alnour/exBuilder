export default insertMeta;
declare function insertMeta({ profiles, mapping, item, imageSrc, noindex }: {
    profiles?: string;
    mapping: any;
    item: any;
    imageSrc: any;
    noindex: any;
}): void;
