import { UserSession } from '@esri/arcgis-rest-auth';
export declare function completeOAuth2(options: any, win: any): UserSession;
