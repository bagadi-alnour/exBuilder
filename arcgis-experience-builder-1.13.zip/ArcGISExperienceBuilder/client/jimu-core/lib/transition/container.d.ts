import * as React from 'react';
import { type TransitionContainerProps } from './types';
export declare function TransitionContainer(props: TransitionContainerProps): React.JSX.Element;
