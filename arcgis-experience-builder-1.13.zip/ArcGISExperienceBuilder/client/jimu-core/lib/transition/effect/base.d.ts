export declare const DEFAULT_TRANSITION_PROPS: {
    rotateX: number;
    rotateY: number;
    x: string;
    y: string;
};
