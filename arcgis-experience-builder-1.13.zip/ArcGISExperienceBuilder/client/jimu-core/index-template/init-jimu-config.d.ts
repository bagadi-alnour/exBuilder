declare function initJimuConfig(): void;
declare function getDeployContextFromLocation(): string;
declare function isInBuilder(): boolean;
