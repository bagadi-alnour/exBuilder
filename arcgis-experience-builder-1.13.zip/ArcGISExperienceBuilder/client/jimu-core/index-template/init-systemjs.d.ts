/**
 * These init must be after systemjs lib load
 */
declare function initSystemJS(): void;
