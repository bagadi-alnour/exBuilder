declare function start(): void;
