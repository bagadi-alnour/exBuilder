/// <reference types="react" />
import { React } from 'jimu-core';
export declare const MockNumericInput: (props: any) => React.JSX.Element;
