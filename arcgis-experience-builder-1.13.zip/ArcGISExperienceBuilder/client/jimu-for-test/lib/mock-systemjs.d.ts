/** Mock SystemJS.import() */
export declare function mockSystemJs(): void;
